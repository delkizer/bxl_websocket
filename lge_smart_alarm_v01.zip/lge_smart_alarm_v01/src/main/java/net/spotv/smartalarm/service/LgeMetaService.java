package net.spotv.smartalarm.service;

public interface LgeMetaService {
	boolean getXmlMeta();
}
