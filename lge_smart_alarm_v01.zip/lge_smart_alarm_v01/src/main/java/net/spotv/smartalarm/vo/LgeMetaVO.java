package net.spotv.smartalarm.vo;

public class LgeMetaVO {
	String titlekr;
	String descriptionKr;
	String imageKr;	
	String imageKrSize;
	String contentType;
	String sportId;
	String sportName;
	String leagueId;
	String leagueName;	
	String teamTypeIdHome;
	String teamTypeNameHome;
	String teamTypeIdAway;
	String teamTypeNameAway;
	String startTime;
	String endTime;
	

	public String getTitlekr() {
		return titlekr;
	}

	public void setTitlekr(String titlekr) {
		this.titlekr = titlekr;
	}

	public String getDescriptionKr() {
		return descriptionKr;
	}

	public void setDescriptionKr(String descriptionKr) {
		this.descriptionKr = descriptionKr;
	}

	public String getImageKr() {
		return imageKr;
	}

	public void setImageKr(String imageKr) {
		this.imageKr = imageKr;
	}
	
	public String getImageKrSize() {
		return imageKrSize;
	}

	public void setImageKrSize(String imageKrSize) {
		this.imageKrSize = imageKrSize;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getSportId() {
		return sportId;
	}

	public void setSportId(String sportId) {
		this.sportId = sportId;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	public String getLeagueId() {
		return leagueId;
	}

	public void setLeagueId(String leagueId) {
		this.leagueId = leagueId;
	}

	public String getLeagueName() {
		return leagueName;
	}

	public void setLeagueName(String leagueName) {
		this.leagueName = leagueName;
	}

	public String getTeamTypeIdHome() {
		return teamTypeIdHome;
	}

	public void setTeamTypeIdHome(String teamTypeIdHome) {
		this.teamTypeIdHome = teamTypeIdHome;
	}

	public String getTeamTypeNameHome() {
		return teamTypeNameHome;
	}

	public void setTeamTypeNameHome(String teamTypeNameHome) {
		this.teamTypeNameHome = teamTypeNameHome;
	}

	public String getTeamTypeIdAway() {
		return teamTypeIdAway;
	}

	public void setTeamTypeIdAway(String teamTypeIdAway) {
		this.teamTypeIdAway = teamTypeIdAway;
	}

	public String getTeamTypeNameAway() {
		return teamTypeNameAway;
	}

	public void setTeamTypeNameAway(String teamTypeNameAway) {
		this.teamTypeNameAway = teamTypeNameAway;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	
}
