package net.spotv.smartalarm.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestVO {
	String test;
	
}
