package net.spotv.smartalarm.service;

import net.spotv.smartalarm.vo.TestVO;

public interface TestService {
	TestVO getTestData();
}
